﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String str = this.textBox1.Text;

            int counter = Int32.Parse(button1.Text);

            String[] lines = str.Split('\n');

            //System.Diagnostics.Process.Start("CMD.exe", lines[counter++ - 1]);

            string strCmdText;
            strCmdText = "/c " + lines[counter++ - 1];
            System.Diagnostics.Process.Start("CMD.exe", strCmdText);
            
            this.button1.Text = counter.ToString();

            string strr = lines[counter - 2];
            int index = strr.IndexOf("\\\\zcak");
            Clipboard.SetText(strr.Substring(index));


        }
    }
}
